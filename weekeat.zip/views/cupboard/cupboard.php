<?php include_once('views/templates/header.php'); ?>
<?php include_once('views/templates/nav-cupboard.php'); ?>


<main class="container">
    <div class="alacena">
        <table class="tb-items-alacena" id="tb-items-alacena ">
            <tr><th></th><th></th><th>Cantidad</th><th><i class="fas fa-ruler-combined"></i></th></tr>
            <?php foreach($data['items'] as $item){ ?>
            <tr>
                <td><img src="img/<?php echo $item['image']; ?>" alt="img.jpg" class="img-items"></td>
                <td><?php echo $item['description']; ?></td>
                <td><?php echo $item['quantity']; ?></td>
                <td><?php echo $item['um']; ?></td>
            </tr> 
            <?php } ?>
           

        </table>   
    </div>
 
       
</main> 
<?php include_once "views/templates/footer.php"; ?>
</body>
</html>