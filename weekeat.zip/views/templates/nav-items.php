<nav class="nav-header">
        <ul class= "container">
            <li><a href="index.php?c=Items&a=index">Lista de Ingredientes</a></li>
            <li><a href="index.php?c=Items&a=edit">Administrar Ingredientes</a></li>
        </ul>
</nav>
</header>