<nav class="nav-header">
        <ul class= "container">
            <li><a href="index.php?c=Recipes&a=index">Lista de Recetas</a></li>
            <li><a href="index.php?c=Recipes&a=newRecipe">Agregar Receta</a></li>
        </ul>
</nav>
</header>