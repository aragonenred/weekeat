<footer>
    <script src="js/main.js"></script>

</footer>