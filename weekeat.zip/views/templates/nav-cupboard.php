<nav class="nav-header">
        <ul class= "container">
            <li><a href="index.php?c=Cupboard&a=index">Mi Alacena</a></li>
            <li><a href="index.php?c=Cupboard&a=edit">Administrar Alacena</a></li>
            <li><a href="#">Lista de Compras</a></li>
        </ul>
</nav>
</header>