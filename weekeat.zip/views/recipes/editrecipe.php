<?php include_once('views/templates/header.php'); ?>
<?php include_once('views/templates/nav-recipes.php'); ?>


</main>

<?php include_once "views/templates/footer.php"; ?>
</body>
</html>