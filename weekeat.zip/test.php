<?
    phpinfo();
?>
