<?php

define("DEFAULT_CONTROLLER", "Recipes");
define("DEFAULT_ACTION", "index");


?>